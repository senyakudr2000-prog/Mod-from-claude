package com.lostphysics.registry;

import com.lostphysics.LostPhysics;
import com.lostphysics.entity.PhysicsProp;
import com.lostphysics.item.PropItem;
import com.lostphysics.physics.PropType;
import net.minecraft.core.registries.Registries;
import net.minecraft.network.chat.Component;
import net.minecraft.world.item.CreativeModeTab;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredItem;
import net.neoforged.neoforge.registries.DeferredRegister;

import java.util.EnumMap;
import java.util.Map;

public final class ModItems {
    public static final DeferredRegister.Items ITEMS = DeferredRegister.createItems(LostPhysics.MODID);
    public static final DeferredRegister<CreativeModeTab> TABS =
            DeferredRegister.create(Registries.CREATIVE_MODE_TAB, LostPhysics.MODID);

    private static final Map<PropType, DeferredItem<PropItem>> PROP_ITEMS = new EnumMap<>(PropType.class);

    static {
        for (PropType t : PropType.values()) {
            PROP_ITEMS.put(t, ITEMS.register(t.id(), () -> new PropItem(new Item.Properties(), t)));
        }
    }

    public static final DeferredHolder<CreativeModeTab, CreativeModeTab> TAB = TABS.register("main",
            () -> CreativeModeTab.builder()
                    .title(Component.translatable("itemGroup.lostphysics"))
                    .icon(() -> new ItemStack(PROP_ITEMS.get(PropType.CRATE).get()))
                    .displayItems((params, out) -> {
                        for (PropType t : PropType.values()) out.accept(PROP_ITEMS.get(t).get());
                    })
                    .build());

    public static Item item(PropType t) { return PROP_ITEMS.get(t).get(); }

    /** Server-side helper: creates, positions and adds a prop. */
    public static PhysicsProp spawn(Level level, PropType type, Vec3 bottomCenter) {
        PhysicsProp p = ModEntities.PROP.get().create(level);
        if (p == null) return null;
        p.setPropType(type);
        p.setPos(bottomCenter.x, bottomCenter.y, bottomCenter.z);
        level.addFreshEntity(p);
        return p;
    }

    private ModItems() {}
}
