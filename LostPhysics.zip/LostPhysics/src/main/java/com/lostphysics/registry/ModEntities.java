package com.lostphysics.registry;

import com.lostphysics.LostPhysics;
import com.lostphysics.entity.PhysicsProp;
import net.minecraft.core.registries.Registries;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MobCategory;
import net.neoforged.neoforge.registries.DeferredHolder;
import net.neoforged.neoforge.registries.DeferredRegister;

public final class ModEntities {
    public static final DeferredRegister<EntityType<?>> ENTITIES =
            DeferredRegister.create(Registries.ENTITY_TYPE, LostPhysics.MODID);

    public static final DeferredHolder<EntityType<?>, EntityType<PhysicsProp>> PROP = ENTITIES.register("prop",
            () -> EntityType.Builder.<PhysicsProp>of(PhysicsProp::new, MobCategory.MISC)
                    .sized(0.6f, 0.6f)
                    .clientTrackingRange(8)
                    .updateInterval(1)
                    .build("prop"));

    private ModEntities() {}
}
