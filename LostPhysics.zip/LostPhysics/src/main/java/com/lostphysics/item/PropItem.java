package com.lostphysics.item;

import com.lostphysics.entity.PhysicsProp;
import com.lostphysics.physics.PropType;
import com.lostphysics.registry.ModItems;
import net.minecraft.core.BlockPos;
import net.minecraft.core.Direction;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.Item;
import net.minecraft.world.item.context.UseOnContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.Vec3;

public class PropItem extends Item {
    private final PropType type;

    public PropItem(Properties props, PropType type) {
        super(props);
        this.type = type;
    }

    public PropType getPropType() { return type; }

    @Override
    public InteractionResult useOn(UseOnContext ctx) {
        Level level = ctx.getLevel();
        if (level.isClientSide) return InteractionResult.SUCCESS;
        BlockPos clicked = ctx.getClickedPos();
        Direction face = ctx.getClickedFace();
        Vec3 pos = Vec3.atBottomCenterOf(clicked.relative(face));
        if (face == Direction.UP) {
            pos = new Vec3(ctx.getClickLocation().x, clicked.getY() + 1.0, ctx.getClickLocation().z);
        } else if (face == Direction.DOWN) {
            pos = pos.add(0, -type.height, 0);
        }
        PhysicsProp prop = ModItems.spawn(level, type, pos);
        if (prop == null) return InteractionResult.FAIL;
        Player player = ctx.getPlayer();
        if (player != null) {
            prop.rotateYawInstant(Math.round((player.getYRot() + 180f) / 15f) * 15f);
            if (!player.getAbilities().instabuild) ctx.getItemInHand().shrink(1);
        }
        return InteractionResult.CONSUME;
    }
}
