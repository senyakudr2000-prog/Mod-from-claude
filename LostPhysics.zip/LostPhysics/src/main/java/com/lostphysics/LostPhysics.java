package com.lostphysics;

import com.lostphysics.network.ModNetwork;
import com.lostphysics.registry.ModEntities;
import com.lostphysics.registry.ModItems;
import net.neoforged.bus.api.IEventBus;
import net.neoforged.fml.ModContainer;
import net.neoforged.fml.common.Mod;
import net.neoforged.fml.config.ModConfig;

@Mod(LostPhysics.MODID)
public class LostPhysics {
    public static final String MODID = "lostphysics";

    public LostPhysics(IEventBus modBus, ModContainer container) {
        ModEntities.ENTITIES.register(modBus);
        ModItems.ITEMS.register(modBus);
        ModItems.TABS.register(modBus);
        modBus.addListener(ModNetwork::register);
        container.registerConfig(ModConfig.Type.COMMON, Config.SPEC);
    }
}
