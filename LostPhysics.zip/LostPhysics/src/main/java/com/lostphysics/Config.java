package com.lostphysics;

import net.neoforged.neoforge.common.ModConfigSpec;

public final class Config {
    private static final ModConfigSpec.Builder B = new ModConfigSpec.Builder();

    public static final ModConfigSpec.IntValue MAX_ACTIVE = B
            .comment("Max physics props simulated per tick per dimension (extra ones pause for a tick).")
            .defineInRange("maxActiveProps", 64, 1, 1024);
    public static final ModConfigSpec.DoubleValue GRAB_RANGE = B
            .comment("Max grab distance in blocks.")
            .defineInRange("grabRange", 5.0, 2.0, 12.0);
    public static final ModConfigSpec.DoubleValue THROW_SPEED = B
            .comment("Base throw speed (blocks/tick) for a 1 kg prop.")
            .defineInRange("throwSpeed", 1.6, 0.2, 4.0);
    public static final ModConfigSpec.DoubleValue PUSH_STRENGTH = B
            .comment("Multiplier for how strongly players push props by walking into them.")
            .defineInRange("pushStrength", 1.0, 0.0, 5.0);

    public static final ModConfigSpec SPEC = B.build();

    private Config() {}
}
