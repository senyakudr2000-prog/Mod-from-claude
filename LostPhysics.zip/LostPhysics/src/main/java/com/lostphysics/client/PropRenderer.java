package com.lostphysics.client;

import com.lostphysics.LostPhysics;
import com.lostphysics.entity.PhysicsProp;
import com.lostphysics.physics.PropType;
import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import com.mojang.math.Axis;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.renderer.entity.EntityRenderer;
import net.minecraft.client.renderer.entity.EntityRendererProvider;
import net.minecraft.client.renderer.texture.OverlayTexture;
import net.minecraft.resources.ResourceLocation;
import net.minecraft.util.Mth;

import java.util.EnumMap;
import java.util.Map;

/** Draws props as small box models (several cuboids per type). */
public class PropRenderer extends EntityRenderer<PhysicsProp> {
    /** x0,y0,z0,x1,y1,z1 (metres, origin = bottom centre), yaw (deg), tint (0..1). */
    private record Cuboid(float x0, float y0, float z0, float x1, float y1, float z1, float yaw, float tint) {
        Cuboid(float x0, float y0, float z0, float x1, float y1, float z1) {
            this(x0, y0, z0, x1, y1, z1, 0f, 1f);
        }
    }

    private static final Map<PropType, Cuboid[]> MODELS = new EnumMap<>(PropType.class);

    static {
        MODELS.put(PropType.CHAIR, new Cuboid[]{
                new Cuboid(-.25f, .42f, -.25f, .25f, .50f, .25f),
                new Cuboid(-.25f, 0f, -.25f, -.21f, .42f, -.21f, 0f, .8f),
                new Cuboid(.21f, 0f, -.25f, .25f, .42f, -.21f, 0f, .8f),
                new Cuboid(-.25f, 0f, .21f, -.21f, .42f, .25f, 0f, .8f),
                new Cuboid(.21f, 0f, .21f, .25f, .42f, .25f, 0f, .8f),
                new Cuboid(-.25f, .50f, .21f, .25f, .90f, .25f, 0f, .9f)});
        MODELS.put(PropType.TABLE, new Cuboid[]{
                new Cuboid(-.5f, .67f, -.4f, .5f, .75f, .4f),
                new Cuboid(-.48f, 0f, -.38f, -.40f, .67f, -.30f, 0f, .8f),
                new Cuboid(.40f, 0f, -.38f, .48f, .67f, -.30f, 0f, .8f),
                new Cuboid(-.48f, 0f, .30f, -.40f, .67f, .38f, 0f, .8f),
                new Cuboid(.40f, 0f, .30f, .48f, .67f, .38f, 0f, .8f)});
        MODELS.put(PropType.CRATE, new Cuboid[]{
                new Cuboid(-.45f, 0f, -.45f, .45f, .9f, .45f),
                new Cuboid(-.46f, 0f, -.46f, -.36f, .9f, -.36f, 0f, .7f),
                new Cuboid(.36f, 0f, -.46f, .46f, .9f, -.36f, 0f, .7f),
                new Cuboid(-.46f, 0f, .36f, -.36f, .9f, .46f, 0f, .7f),
                new Cuboid(.36f, 0f, .36f, .46f, .9f, .46f, 0f, .7f)});
        MODELS.put(PropType.BOX, new Cuboid[]{
                new Cuboid(-.25f, 0f, -.25f, .25f, .5f, .25f)});
        MODELS.put(PropType.BARREL, new Cuboid[]{
                new Cuboid(-.33f, 0f, -.33f, .33f, 1f, .33f),
                new Cuboid(-.33f, 0f, -.33f, .33f, 1f, .33f, 45f, 1f),
                new Cuboid(-.345f, .12f, -.345f, .345f, .18f, .345f, 0f, .6f),
                new Cuboid(-.345f, .12f, -.345f, .345f, .18f, .345f, 45f, .6f),
                new Cuboid(-.345f, .82f, -.345f, .345f, .88f, .345f, 0f, .6f),
                new Cuboid(-.345f, .82f, -.345f, .345f, .88f, .345f, 45f, .6f)});
        MODELS.put(PropType.BOTTLE, new Cuboid[]{
                new Cuboid(-.08f, 0f, -.08f, .08f, .32f, .08f),
                new Cuboid(-.035f, .32f, -.035f, .035f, .50f, .035f)});
        MODELS.put(PropType.VASE, new Cuboid[]{
                new Cuboid(-.12f, 0f, -.12f, .12f, .08f, .12f, 0f, .85f),
                new Cuboid(-.17f, .08f, -.17f, .17f, .30f, .17f),
                new Cuboid(-.09f, .30f, -.09f, .09f, .45f, .09f)});
    }

    public PropRenderer(EntityRendererProvider.Context ctx) {
        super(ctx);
        this.shadowRadius = 0.3f;
    }

    @Override
    public ResourceLocation getTextureLocation(PhysicsProp entity) {
        return ResourceLocation.fromNamespaceAndPath(LostPhysics.MODID,
                "textures/entity/" + entity.getPropType().material.name().toLowerCase() + ".png");
    }

    @Override
    public void render(PhysicsProp entity, float yaw, float partialTick, PoseStack stack,
                       MultiBufferSource buffers, int light) {
        PropType type = entity.getPropType();
        Cuboid[] model = MODELS.get(type);
        if (model == null) return;

        float rx = Mth.rotLerp(partialTick, entity.prevDispRotX, entity.dispRotX);
        float ry = Mth.rotLerp(partialTick, entity.prevDispRotY, entity.dispRotY);
        float grab = Mth.lerp(partialTick, entity.prevGrabAnim, entity.grabAnim);
        float scale = 1f + 0.06f * grab;

        stack.pushPose();
        stack.translate(0, type.height / 2f, 0);
        stack.mulPose(Axis.YP.rotationDegrees(-ry));
        stack.mulPose(Axis.XP.rotationDegrees(rx));
        stack.scale(scale, scale, scale);
        stack.translate(0, -type.height / 2f, 0);

        VertexConsumer vc = buffers.getBuffer(RenderType.entityCutoutNoCull(getTextureLocation(entity)));
        for (Cuboid c : model) {
            stack.pushPose();
            if (c.yaw != 0f) stack.mulPose(Axis.YP.rotationDegrees(c.yaw));
            box(vc, stack.last(), c, light);
            stack.popPose();
        }
        stack.popPose();
        super.render(entity, yaw, partialTick, stack, buffers, light);
    }

    private static void box(VertexConsumer vc, PoseStack.Pose pose, Cuboid c, int light) {
        float x0 = c.x0, y0 = c.y0, z0 = c.z0, x1 = c.x1, y1 = c.y1, z1 = c.z1;
        int t = Math.round(255f * c.tint);
        // up, down, north, south, west, east
        quad(vc, pose, light, t, 0, 1, 0, x0, y1, z0, x0, y1, z1, x1, y1, z1, x1, y1, z0);
        quad(vc, pose, light, t, 0, -1, 0, x0, y0, z1, x0, y0, z0, x1, y0, z0, x1, y0, z1);
        quad(vc, pose, light, t, 0, 0, -1, x1, y0, z0, x0, y0, z0, x0, y1, z0, x1, y1, z0);
        quad(vc, pose, light, t, 0, 0, 1, x0, y0, z1, x1, y0, z1, x1, y1, z1, x0, y1, z1);
        quad(vc, pose, light, t, -1, 0, 0, x0, y0, z0, x0, y0, z1, x0, y1, z1, x0, y1, z0);
        quad(vc, pose, light, t, 1, 0, 0, x1, y0, z1, x1, y0, z0, x1, y1, z0, x1, y1, z1);
    }

    private static void quad(VertexConsumer vc, PoseStack.Pose pose, int light, int tint,
                             float nx, float ny, float nz,
                             float ax, float ay, float az, float bx, float by, float bz,
                             float cx, float cy, float cz, float dx, float dy, float dz) {
        vertex(vc, pose, light, tint, nx, ny, nz, ax, ay, az, 0f, 1f);
        vertex(vc, pose, light, tint, nx, ny, nz, bx, by, bz, 1f, 1f);
        vertex(vc, pose, light, tint, nx, ny, nz, cx, cy, cz, 1f, 0f);
        vertex(vc, pose, light, tint, nx, ny, nz, dx, dy, dz, 0f, 0f);
    }

    private static void vertex(VertexConsumer vc, PoseStack.Pose pose, int light, int tint,
                               float nx, float ny, float nz, float x, float y, float z, float u, float v) {
        vc.addVertex(pose, x, y, z)
                .setColor(tint, tint, tint, 255)
                .setUv(u, v)
                .setOverlay(OverlayTexture.NO_OVERLAY)
                .setLight(light)
                .setNormal(pose, nx, ny, nz);
    }
}
