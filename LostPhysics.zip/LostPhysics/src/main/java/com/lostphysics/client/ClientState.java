package com.lostphysics.client;

/** Plain state holder, safe to reference from common code (no client classes). */
public final class ClientState {
    public static volatile boolean holding;

    private ClientState() {}
}
