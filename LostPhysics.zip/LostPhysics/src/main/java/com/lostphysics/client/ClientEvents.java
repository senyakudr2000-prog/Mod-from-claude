package com.lostphysics.client;

import com.lostphysics.Config;
import com.lostphysics.LostPhysics;
import com.lostphysics.entity.PhysicsProp;
import com.lostphysics.network.ActionPayload;
import com.lostphysics.physics.PropManager;
import net.minecraft.client.Minecraft;
import net.minecraft.client.player.LocalPlayer;
import net.neoforged.api.distmarker.Dist;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.client.event.ClientPlayerNetworkEvent;
import net.neoforged.neoforge.client.event.ClientTickEvent;
import net.neoforged.neoforge.client.event.InputEvent;
import net.neoforged.neoforge.network.PacketDistributor;

@EventBusSubscriber(modid = LostPhysics.MODID, value = Dist.CLIENT)
public final class ClientEvents {
    private static PhysicsProp highlighted;

    private ClientEvents() {}

    @SubscribeEvent
    public static void onClientTick(ClientTickEvent.Post event) {
        Minecraft mc = Minecraft.getInstance();
        LocalPlayer player = mc.player;
        if (player == null || mc.level == null) {
            clearHighlight();
            return;
        }
        boolean inGame = mc.screen == null;

        while (ClientSetup.GRAB.consumeClick()) {
            if (inGame && !player.isSpectator()) send(ActionPayload.TOGGLE, 0, 0);
        }

        if (inGame && ClientState.holding && ClientSetup.ROTATE.isDown()) {
            if (player.isShiftKeyDown()) send(ActionPayload.ROTATE, 0, 6f);
            else send(ActionPayload.ROTATE, 6f, 0);
        }

        // highlight the prop the player is looking at
        PhysicsProp target = null;
        if (inGame && !ClientState.holding && !player.isSpectator()) {
            target = PropManager.rayTrace(player, Config.GRAB_RANGE.get(), null);
        }
        if (target != highlighted) {
            clearHighlight();
            if (target != null) {
                target.clientHighlight = true;
                highlighted = target;
            }
        }
    }

    private static void clearHighlight() {
        if (highlighted != null) {
            highlighted.clientHighlight = false;
            highlighted = null;
        }
    }

    @SubscribeEvent
    public static void onScroll(InputEvent.MouseScrollingEvent event) {
        Minecraft mc = Minecraft.getInstance();
        if (ClientState.holding && mc.screen == null && mc.player != null) {
            send(ActionPayload.SCROLL, (float) event.getScrollDeltaY(), 0);
            event.setCanceled(true);
        }
    }

    @SubscribeEvent
    public static void onInteraction(InputEvent.InteractionKeyMappingTriggered event) {
        if (!ClientState.holding) return;
        if (event.isAttack()) {
            send(ActionPayload.THROW, 0, 0);
            event.setSwingHand(false);
            event.setCanceled(true);
        } else if (event.isUseItem()) {
            send(ActionPayload.PLACE, 0, 0);
            event.setSwingHand(false);
            event.setCanceled(true);
        }
    }

    @SubscribeEvent
    public static void onLogout(ClientPlayerNetworkEvent.LoggingOut event) {
        ClientState.holding = false;
        clearHighlight();
    }

    private static void send(byte action, float a, float b) {
        PacketDistributor.sendToServer(new ActionPayload(action, a, b));
    }
}
