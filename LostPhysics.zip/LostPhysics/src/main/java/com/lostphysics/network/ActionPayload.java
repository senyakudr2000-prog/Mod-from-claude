package com.lostphysics.network;

import com.lostphysics.LostPhysics;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

/** Client -> server: a grab-related action. */
public record ActionPayload(byte action, float a, float b) implements CustomPacketPayload {
    public static final byte TOGGLE = 0;  // grab / release
    public static final byte SCROLL = 1;  // a = wheel delta
    public static final byte ROTATE = 2;  // a = yaw delta, b = pitch delta
    public static final byte THROW = 3;
    public static final byte PLACE = 4;

    public static final Type<ActionPayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(LostPhysics.MODID, "action"));

    public static final StreamCodec<FriendlyByteBuf, ActionPayload> CODEC = StreamCodec.of(
            (buf, p) -> {
                buf.writeByte(p.action);
                buf.writeFloat(p.a);
                buf.writeFloat(p.b);
            },
            buf -> new ActionPayload(buf.readByte(), buf.readFloat(), buf.readFloat()));

    @Override
    public Type<? extends CustomPacketPayload> type() { return TYPE; }
}
