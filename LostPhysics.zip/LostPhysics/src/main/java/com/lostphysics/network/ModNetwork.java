package com.lostphysics.network;

import com.lostphysics.client.ClientState;
import com.lostphysics.physics.PropManager;
import net.minecraft.server.level.ServerPlayer;
import net.neoforged.neoforge.network.event.RegisterPayloadHandlersEvent;
import net.neoforged.neoforge.network.registration.PayloadRegistrar;

public final class ModNetwork {
    public static void register(RegisterPayloadHandlersEvent event) {
        PayloadRegistrar reg = event.registrar("1");
        reg.playToServer(ActionPayload.TYPE, ActionPayload.CODEC, (payload, ctx) -> {
            if (ctx.player() instanceof ServerPlayer sp) {
                PropManager.handleAction(sp, payload);
            }
        });
        reg.playToClient(HoldStatePayload.TYPE, HoldStatePayload.CODEC,
                (payload, ctx) -> ClientState.holding = payload.holding());
    }

    private ModNetwork() {}
}
