package com.lostphysics.network;

import com.lostphysics.LostPhysics;
import net.minecraft.network.FriendlyByteBuf;
import net.minecraft.network.codec.StreamCodec;
import net.minecraft.network.protocol.common.custom.CustomPacketPayload;
import net.minecraft.resources.ResourceLocation;

/** Server -> client: whether this player is currently holding a prop. */
public record HoldStatePayload(boolean holding) implements CustomPacketPayload {
    public static final Type<HoldStatePayload> TYPE =
            new Type<>(ResourceLocation.fromNamespaceAndPath(LostPhysics.MODID, "hold_state"));

    public static final StreamCodec<FriendlyByteBuf, HoldStatePayload> CODEC = StreamCodec.of(
            (buf, p) -> buf.writeBoolean(p.holding),
            buf -> new HoldStatePayload(buf.readBoolean()));

    @Override
    public Type<? extends CustomPacketPayload> type() { return TYPE; }
}
