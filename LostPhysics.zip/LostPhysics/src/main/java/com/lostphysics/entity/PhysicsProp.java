package com.lostphysics.entity;

import com.lostphysics.LostPhysics;
import com.lostphysics.physics.PropManager;
import com.lostphysics.physics.PropMaterial;
import com.lostphysics.physics.PropType;
import com.lostphysics.registry.ModItems;
import net.minecraft.core.BlockPos;
import net.minecraft.nbt.CompoundTag;
import net.minecraft.nbt.IntArrayTag;
import net.minecraft.nbt.Tag;
import net.minecraft.network.syncher.EntityDataAccessor;
import net.minecraft.network.syncher.EntityDataSerializers;
import net.minecraft.network.syncher.SynchedEntityData;
import net.minecraft.server.level.ServerLevel;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.InteractionHand;
import net.minecraft.world.InteractionResult;
import net.minecraft.world.damagesource.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.EntityDimensions;
import net.minecraft.world.entity.EntityType;
import net.minecraft.world.entity.MoverType;
import net.minecraft.world.entity.Pose;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.item.ItemStack;
import net.minecraft.world.level.Level;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;

/**
 * A single physical prop. One entity type, many {@link PropType} variants.
 * Simulation runs server side only; clients just receive position + synced rotation.
 */
public class PhysicsProp extends Entity {
    private static final EntityDataAccessor<Integer> DATA_TYPE =
            SynchedEntityData.defineId(PhysicsProp.class, EntityDataSerializers.INT);
    private static final EntityDataAccessor<Boolean> DATA_HELD =
            SynchedEntityData.defineId(PhysicsProp.class, EntityDataSerializers.BOOLEAN);
    private static final EntityDataAccessor<Float> DATA_ROT_X =
            SynchedEntityData.defineId(PhysicsProp.class, EntityDataSerializers.FLOAT);
    private static final EntityDataAccessor<Float> DATA_ROT_Y =
            SynchedEntityData.defineId(PhysicsProp.class, EntityDataSerializers.FLOAT);

    // ---- server state ----
    private float rotX, rotY, angVelX, angVelY;
    private boolean sleeping;
    private int idleTicks;
    private int lastSoundTick = -100;
    private int lastSlideTick = -100;
    private final List<Integer> contents = new ArrayList<>();
    private UUID holder;
    private Vec3 holdTarget;
    private int holdRefreshTick;

    // ---- client render state (smoothed) ----
    public float dispRotX, dispRotY, prevDispRotX, prevDispRotY;
    public float grabAnim, prevGrabAnim;
    /** Client-only: outline shown while the local player looks at this prop. */
    public boolean clientHighlight;

    public PhysicsProp(EntityType<? extends PhysicsProp> type, Level level) {
        super(type, level);
    }

    @Override
    protected void defineSynchedData(SynchedEntityData.Builder builder) {
        builder.define(DATA_TYPE, 0);
        builder.define(DATA_HELD, false);
        builder.define(DATA_ROT_X, 0f);
        builder.define(DATA_ROT_Y, 0f);
    }

    @Override
    public void onSyncedDataUpdated(EntityDataAccessor<?> key) {
        if (DATA_TYPE.equals(key)) refreshDimensions();
        super.onSyncedDataUpdated(key);
    }

    @Override
    public EntityDimensions getDimensions(Pose pose) {
        PropType t = getPropType();
        return EntityDimensions.fixed(Math.max(t.width, t.depth), t.height);
    }

    // ---------------------------------------------------------------- accessors

    public PropType getPropType() { return PropType.byOrdinal(entityData.get(DATA_TYPE)); }

    public void setPropType(PropType t) {
        entityData.set(DATA_TYPE, t.ordinal());
        refreshDimensions();
    }

    public boolean isHeld() { return entityData.get(DATA_HELD); }
    public UUID getHolder() { return holder; }
    public float getRotX() { return entityData.get(DATA_ROT_X); }
    public float getRotY() { return entityData.get(DATA_ROT_Y); }
    public int getContentCount() { return contents.size(); }
    public boolean isSleeping() { return sleeping; }

    @Override
    public boolean isCurrentlyGlowing() {
        return (level().isClientSide && clientHighlight) || super.isCurrentlyGlowing();
    }

    @Override public boolean isPickable() { return true; }
    @Override public boolean canBeCollidedWith() { return !isHeld(); }
    @Override public boolean isPushedByFluid() { return false; }
    @Override protected boolean isMovementNoisy() { return false; }
    @Override public boolean isAttackable() { return true; }

    // ---------------------------------------------------------------- tick

    @Override
    public void tick() {
        super.tick();
        if (level().isClientSide) {
            clientTick();
        } else {
            serverTick();
        }
    }

    private void clientTick() {
        prevDispRotX = dispRotX;
        prevDispRotY = dispRotY;
        prevGrabAnim = grabAnim;
        dispRotX += Mth.wrapDegrees(getRotX() - dispRotX) * 0.5f;
        dispRotY += Mth.wrapDegrees(getRotY() - dispRotY) * 0.5f;
        grabAnim += ((isHeld() ? 1f : 0f) - grabAnim) * 0.4f;
    }

    private void serverTick() {
        if (getY() < level().getMinBuildHeight() - 32) {
            discard();
            return;
        }
        if (holder != null) {
            heldTick();
            return;
        }
        if (sleeping) {
            if (tickCount % 10 == 0 && !hasSupport()) {
                wake();
            } else {
                return;
            }
        }
        if (!PropManager.tryActivate(level(), this)) return;
        freeTick();
    }

    /** True if something solid (block or another prop) is right below. */
    private boolean hasSupport() {
        AABB below = getBoundingBox().move(0, -0.04, 0);
        return !level().noCollision(this, below);
    }

    private void freeTick() {
        PropType type = getPropType();
        PropMaterial mat = type.material;
        Vec3 v = getDeltaMovement();

        boolean inWater = isInWater();
        v = v.add(0, inWater ? -0.02 : -0.08, 0);
        if (inWater) {
            if (type.material == PropMaterial.WOOD || type.material == PropMaterial.CARDBOARD) {
                v = v.add(0, 0.06, 0);
            }
            v = v.scale(0.85);
        } else {
            v = v.scale(1.0 - mat.airDrag);
        }

        v = collideWithProps(v, type);

        Vec3 before = position();
        move(MoverType.SELF, v);
        Vec3 moved = position().subtract(before);

        double eps = 1.0e-5;
        boolean cx = Math.abs(moved.x) < Math.abs(v.x) - eps;
        boolean cy = Math.abs(moved.y) < Math.abs(v.y) - eps;
        boolean cz = Math.abs(moved.z) < Math.abs(v.z) - eps;
        double e = mat.restitution;
        double nx = v.x, ny = v.y, nz = v.z;
        double impact = 0;
        if (cx) { impact = Math.max(impact, Math.abs(v.x)); nx = Math.abs(v.x) > 0.08 ? -v.x * e : 0; }
        if (cz) { impact = Math.max(impact, Math.abs(v.z)); nz = Math.abs(v.z) > 0.08 ? -v.z * e : 0; }
        if (cy) {
            if (v.y < 0) impact = Math.max(impact, -v.y);
            else impact = Math.max(impact, v.y);
            ny = Math.abs(v.y) > 0.14 ? -v.y * e : 0;
        }
        boolean landed = cy && v.y < 0;

        if (landed) {
            BlockPos below = getBlockPosBelowThatAffectsMyMovement();
            float bf = level().getBlockState(below).getBlock().getFriction();
            double f = 1.0 - mat.grip * (1.0 - bf);
            nx *= f;
            nz *= f;
        }
        setDeltaMovement(nx, ny, nz);

        if (impact > 0.12) {
            impactEffects(impact, type);
            if (!landed || impact > 0.3) {
                angVelX += (random.nextFloat() - 0.5f) * (float) impact * 40f;
                angVelY += (random.nextFloat() - 0.5f) * (float) impact * 40f;
            }
        }

        // sliding sound (moving furniture)
        double hs = Math.sqrt(nx * nx + nz * nz);
        if (onGround() && hs > 0.06 && tickCount - lastSlideTick > 6) {
            lastSlideTick = tickCount;
            level().playSound(null, getX(), getY(), getZ(), mat.slide(), SoundSource.NEUTRAL,
                    (float) Math.min(0.5, hs * 2), 0.6f + 0.4f / Math.max(0.5f, type.mass * 0.3f));
        }

        updateRotation();

        // go to sleep when settled
        if (onGround() && getDeltaMovement().lengthSqr() < 1.0e-4 && Math.abs(angVelX) + Math.abs(angVelY) < 1f) {
            if (++idleTicks >= 20) {
                sleeping = true;
                setDeltaMovement(Vec3.ZERO);
                angVelX = angVelY = 0;
            }
        } else {
            idleTicks = 0;
        }
    }

    /** Momentum exchange with neighbouring props (horizontal contacts only; stacking is handled by block/entity collision). */
    private Vec3 collideWithProps(Vec3 v, PropType type) {
        if (v.x * v.x + v.z * v.z < 1.0e-4) return v;
        AABB swept = getBoundingBox().expandTowards(v.x, 0, v.z).inflate(0.02, 0, 0.02);
        List<PhysicsProp> others = level().getEntitiesOfClass(PhysicsProp.class, swept,
                o -> o != this && !o.isHeld());
        if (others.isEmpty()) return v;
        double vx = v.x, vz = v.z;
        for (PhysicsProp o : others) {
            AABB a = getBoundingBox();
            AABB b = o.getBoundingBox();
            double overlapY = Math.min(a.maxY, b.maxY) - Math.max(a.minY, b.minY);
            if (overlapY < 0.05) continue; // one is on top of the other
            Vec3 ca = a.getCenter();
            Vec3 cb = b.getCenter();
            double dx = cb.x - ca.x;
            double dz = cb.z - ca.z;
            double sepX = Math.abs(dx) - (a.getXsize() + b.getXsize()) * 0.5;
            double sepZ = Math.abs(dz) - (a.getZsize() + b.getZsize()) * 0.5;
            double nxs = 0, nzs = 0;
            if (sepX > sepZ) nxs = Math.signum(dx); else nzs = Math.signum(dz);
            Vec3 ov = o.getDeltaMovement();
            double rel = (vx - ov.x) * nxs + (vz - ov.z) * nzs;
            if (rel <= 0.01) continue;
            double m1 = type.mass;
            double m2 = o.getPropType().mass;
            double e = Math.min(type.material.restitution, o.getPropType().material.restitution) + 0.1;
            double j = (1 + e) * rel / (1.0 / m1 + 1.0 / m2);
            vx -= j / m1 * nxs;
            vz -= j / m1 * nzs;
            o.impulse(new Vec3(j / m2 * nxs, 0, j / m2 * nzs));
            if (rel > 0.15) o.impactEffects(rel, o.getPropType());
        }
        return new Vec3(vx, v.y, vz);
    }

    private void updateRotation() {
        if (onGround()) {
            angVelX *= 0.4f;
            angVelY *= 0.4f;
            rotX += (0 - rotX) * 0.35f;
        } else {
            angVelX *= 0.98f;
            angVelY *= 0.98f;
        }
        rotX = Mth.wrapDegrees(rotX + angVelX);
        rotY = Mth.wrapDegrees(rotY + angVelY);
        syncRot();
    }

    private void syncRot() {
        if (Math.abs(Mth.wrapDegrees(rotX - getRotX())) > 0.25f) entityData.set(DATA_ROT_X, rotX);
        if (Math.abs(Mth.wrapDegrees(rotY - getRotY())) > 0.25f) entityData.set(DATA_ROT_Y, rotY);
    }

    private void heldTick() {
        PropType type = getPropType();
        if (holdTarget == null || tickCount - holdRefreshTick > 5) {
            release(Vec3.ZERO, false);
            return;
        }
        Vec3 to = holdTarget.subtract(getBoundingBox().getCenter());
        double maxSpeed = 1.3 / (1.0 + type.mass * 0.06);
        Vec3 v = to.scale(0.5);
        if (v.length() > maxSpeed) v = v.normalize().scale(maxSpeed);
        Vec3 before = position();
        move(MoverType.SELF, v);
        setDeltaMovement(position().subtract(before));
        fallDistance = 0;
        angVelX = angVelY = 0;
        syncRot();
    }

    // ---------------------------------------------------------------- impulses / grabbing

    public void impulse(Vec3 dv) {
        if (level().isClientSide) return;
        setDeltaMovement(getDeltaMovement().add(dv));
        hasImpulse = true;
        wake();
    }

    public void rotateYawInstant(float y) {
        rotY = Mth.wrapDegrees(y);
        entityData.set(DATA_ROT_Y, rotY);
    }

    public void wake() {
        sleeping = false;
        idleTicks = 0;
    }

    public void addSpin(float x, float y) {
        angVelX += x;
        angVelY += y;
        wake();
    }

    /** Called by the grab manager every server tick while held. */
    public void hold(Player player, Vec3 target) {
        if (holder == null) {
            holder = player.getUUID();
            entityData.set(DATA_HELD, true);
            wake();
        }
        holdTarget = target;
        holdRefreshTick = tickCount;
    }

    public void rotateHeld(float yaw, float pitch) {
        if (holder == null) return;
        rotY = Mth.wrapDegrees(rotY + yaw);
        rotX = Mth.clamp(rotX + pitch, -180f, 180f);
        syncRot();
    }

    public void release(Vec3 velocity, boolean spin) {
        holder = null;
        holdTarget = null;
        entityData.set(DATA_HELD, false);
        setDeltaMovement(velocity);
        hasImpulse = true;
        wake();
        if (spin) {
            angVelX = (random.nextFloat() - 0.5f) * 30f;
            angVelY = (random.nextFloat() - 0.5f) * 30f;
        }
    }

    /** Gentle placement: no velocity, no spin, yaw snapped to 15 degrees. */
    public void placeDown() {
        release(Vec3.ZERO, false);
        angVelX = angVelY = 0;
        rotY = Math.round(rotY / 15f) * 15f;
        syncRot();
    }

    // ---------------------------------------------------------------- containers

    public boolean tryStore(PhysicsProp inner) {
        PropType t = getPropType();
        if (level().isClientSide || !t.canHold(inner.getPropType()) || contents.size() >= t.capacity) return false;
        contents.add(inner.getPropType().ordinal());
        level().playSound(null, getX(), getY(), getZ(), t.material.land(), SoundSource.NEUTRAL, 0.8f, 1.2f);
        inner.discard();
        wake();
        return true;
    }

    public PhysicsProp popOne() {
        if (level().isClientSide || contents.isEmpty()) return null;
        int ord = contents.remove(contents.size() - 1);
        PhysicsProp p = ModItems.spawn(level(), PropType.byOrdinal(ord),
                new Vec3(getX(), getBoundingBox().maxY + 0.3, getZ()));
        if (p != null) {
            p.setDeltaMovement((random.nextDouble() - 0.5) * 0.2, 0.25, (random.nextDouble() - 0.5) * 0.2);
            level().playSound(null, getX(), getY(), getZ(), getPropType().material.hit(), SoundSource.NEUTRAL, 0.7f, 1.4f);
        }
        return p;
    }

    // ---------------------------------------------------------------- effects

    public void impactEffects(double impact, PropType type) {
        if (!(level() instanceof ServerLevel sl)) return;
        PropMaterial mat = type.material;
        if (tickCount - lastSoundTick >= 3) {
            lastSoundTick = tickCount;
            float vol = (float) Mth.clamp(impact * 1.6 * (0.6 + type.mass * 0.05), 0.1, 1.2);
            float pitch = Mth.clamp(1.4f - type.mass * 0.05f, 0.6f, 1.4f);
            var snd = impact > 0.9 ? mat.heavy() : impact > 0.35 ? mat.land() : mat.hit();
            sl.playSound(null, getX(), getY(), getZ(), snd, SoundSource.NEUTRAL, vol, pitch);
        }
        if (impact > 0.25) {
            int count = (int) Mth.clamp(impact * 12, 2, 16);
            sl.sendParticles(mat.particle(), getX(), getY() + 0.05, getZ(), count,
                    type.width * 0.3, 0.05, type.depth * 0.3, 0.05);
        }
    }

    // ---------------------------------------------------------------- interaction

    @Override
    public boolean hurt(DamageSource source, float amount) {
        if (level().isClientSide || isRemoved()) return false;
        Entity attacker = source.getEntity();
        if (attacker instanceof Player p && source.getDirectEntity() == p) {
            Vec3 look = p.getLookAngle();
            double k = 0.9 / Math.sqrt(getPropType().mass);
            impulse(new Vec3(look.x * k, 0.15 + Math.max(0, look.y) * k * 0.5, look.z * k));
            addSpin((random.nextFloat() - 0.5f) * 20f, (random.nextFloat() - 0.5f) * 20f);
            impactEffects(0.5, getPropType());
            return true;
        }
        if (source.is(net.minecraft.tags.DamageTypeTags.IS_EXPLOSION)) {
            Vec3 src = source.getSourcePosition();
            if (src != null) {
                Vec3 d = position().subtract(src).normalize().scale(1.2 / Math.sqrt(getPropType().mass));
                impulse(d.add(0, 0.3, 0));
                addSpin(15f, 15f);
            }
            return true;
        }
        return false;
    }

    @Override
    public InteractionResult interact(Player player, InteractionHand hand) {
        if (level().isClientSide) return player.isSecondaryUseActive() ? InteractionResult.SUCCESS : InteractionResult.PASS;
        if (!player.isSecondaryUseActive()) return InteractionResult.PASS;
        // sneak + use: pack the prop back into an item
        while (!contents.isEmpty()) popOne();
        ItemStack stack = new ItemStack(ModItems.item(getPropType()));
        if (!player.getInventory().add(stack)) player.drop(stack, false);
        PropManager.forgetProp(this);
        discard();
        return InteractionResult.CONSUME;
    }

    @Override
    public ItemStack getPickResult() {
        return new ItemStack(ModItems.item(getPropType()));
    }

    // ---------------------------------------------------------------- save / load

    @Override
    protected void readAdditionalSaveData(CompoundTag tag) {
        setPropType(PropType.byOrdinal(tag.getInt("Type")));
        rotX = tag.getFloat("RotX");
        rotY = tag.getFloat("RotY");
        entityData.set(DATA_ROT_X, rotX);
        entityData.set(DATA_ROT_Y, rotY);
        contents.clear();
        for (int i : tag.getIntArray("Contents")) contents.add(i);
        sleeping = false;
    }

    @Override
    protected void addAdditionalSaveData(CompoundTag tag) {
        tag.putInt("Type", getPropType().ordinal());
        tag.putFloat("RotX", rotX);
        tag.putFloat("RotY", rotY);
        tag.put("Contents", new IntArrayTag(contents));
    }
}
