package com.lostphysics.physics;

import java.util.Locale;

/** Registered kinds of physics props. Add new constants here to add new props. */
public enum PropType {
    //       w     h     d     mass  material               capacity
    CHAIR(0.50f, 0.90f, 0.50f, 3.0f, PropMaterial.WOOD, 0),
    TABLE(1.00f, 0.75f, 0.80f, 8.0f, PropMaterial.WOOD, 0),
    CRATE(0.90f, 0.90f, 0.90f, 6.0f, PropMaterial.WOOD, 4),
    BOX(0.50f, 0.50f, 0.50f, 1.5f, PropMaterial.CARDBOARD, 0),
    BARREL(0.70f, 1.00f, 0.70f, 7.0f, PropMaterial.METAL, 3),
    BOTTLE(0.20f, 0.50f, 0.20f, 0.3f, PropMaterial.GLASS, 0),
    VASE(0.35f, 0.45f, 0.35f, 0.8f, PropMaterial.GLASS, 0);

    public final float width, height, depth, mass;
    public final PropMaterial material;
    /** How many smaller props this prop can hold inside. */
    public final int capacity;

    PropType(float w, float h, float d, float mass, PropMaterial m, int capacity) {
        this.width = w; this.height = h; this.depth = d;
        this.mass = mass; this.material = m; this.capacity = capacity;
    }

    public String id() { return name().toLowerCase(Locale.ROOT); }

    public float volume() { return width * height * depth; }

    public boolean canHold(PropType inner) {
        return capacity > 0 && inner != this && inner.volume() < volume() * 0.5f;
    }

    public static PropType byOrdinal(int i) {
        PropType[] v = values();
        return v[Math.floorMod(i, v.length)];
    }
}
