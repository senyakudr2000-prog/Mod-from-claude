package com.lostphysics.physics;

import net.minecraft.core.particles.BlockParticleOption;
import net.minecraft.core.particles.ParticleTypes;
import net.minecraft.sounds.SoundEvent;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.SoundType;

public enum PropMaterial {
    //            grip  bounce airDrag  sound              particle block
    WOOD(0.85, 0.25, 0.02, SoundType.WOOD, Blocks.OAK_PLANKS),
    METAL(0.70, 0.30, 0.02, SoundType.METAL, Blocks.IRON_BLOCK),
    GLASS(0.60, 0.15, 0.02, SoundType.GLASS, Blocks.GLASS),
    CARDBOARD(1.00, 0.10, 0.04, SoundType.WOOL, Blocks.BROWN_WOOL);

    public final double grip;
    public final double restitution;
    public final double airDrag;
    public final SoundType sound;
    public final Block particleBlock;

    PropMaterial(double grip, double restitution, double airDrag, SoundType sound, Block particleBlock) {
        this.grip = grip;
        this.restitution = restitution;
        this.airDrag = airDrag;
        this.sound = sound;
        this.particleBlock = particleBlock;
    }

    public SoundEvent hit() { return sound.getHitSound(); }
    public SoundEvent land() { return sound.getPlaceSound(); }
    public SoundEvent heavy() { return this == GLASS ? sound.getBreakSound() : sound.getPlaceSound(); }
    public SoundEvent slide() { return sound.getStepSound(); }

    public BlockParticleOption particle() {
        return new BlockParticleOption(ParticleTypes.BLOCK, particleBlock.defaultBlockState());
    }
}
