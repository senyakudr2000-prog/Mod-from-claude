package com.lostphysics.physics;

import com.lostphysics.Config;
import com.lostphysics.LostPhysics;
import com.lostphysics.entity.PhysicsProp;
import com.lostphysics.network.ActionPayload;
import com.lostphysics.network.HoldStatePayload;
import net.minecraft.network.chat.Component;
import net.minecraft.resources.ResourceKey;
import net.minecraft.server.level.ServerPlayer;
import net.minecraft.sounds.SoundEvents;
import net.minecraft.sounds.SoundSource;
import net.minecraft.util.Mth;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.level.ClipContext;
import net.minecraft.world.level.Level;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.BlockHitResult;
import net.minecraft.world.phys.HitResult;
import net.minecraft.world.phys.Vec3;
import net.neoforged.bus.api.SubscribeEvent;
import net.neoforged.fml.common.EventBusSubscriber;
import net.neoforged.neoforge.event.entity.player.PlayerEvent;
import net.neoforged.neoforge.event.server.ServerStoppedEvent;
import net.neoforged.neoforge.event.tick.PlayerTickEvent;
import net.neoforged.neoforge.network.PacketDistributor;

import java.util.HashMap;
import java.util.Map;
import java.util.Optional;
import java.util.UUID;

/**
 * Central, server-side coordination: grab state per player, player pushing,
 * and the cap on simultaneously simulated props.
 */
@EventBusSubscriber(modid = LostPhysics.MODID)
public final class PropManager {
    private static final class Grab {
        final int entityId;
        double dist;
        boolean started;

        Grab(int id, double dist) { this.entityId = id; this.dist = dist; }
    }

    private static final Map<UUID, Grab> GRABS = new HashMap<>();
    private static final Map<ResourceKey<Level>, int[]> ACTIVE = new HashMap<>();

    private PropManager() {}

    // ------------------------------------------------------------ simulation budget

    /** Returns false when this dimension already simulated its maximum number of props this tick. */
    public static boolean tryActivate(Level level, PhysicsProp prop) {
        int[] a = ACTIVE.computeIfAbsent(level.dimension(), k -> new int[2]);
        int t = (int) level.getGameTime();
        if (a[0] != t) {
            a[0] = t;
            a[1] = 0;
        }
        return ++a[1] <= Config.MAX_ACTIVE.get();
    }

    public static void forgetProp(PhysicsProp prop) {
        UUID h = prop.getHolder();
        if (h != null) GRABS.remove(h);
    }

    // ------------------------------------------------------------ ray casting (client + server)

    public static PhysicsProp rayTrace(Entity viewer, double range, PhysicsProp ignore) {
        Level level = viewer.level();
        Vec3 start = viewer.getEyePosition();
        Vec3 look = viewer.getViewVector(1.0f);
        Vec3 end = start.add(look.scale(range));
        BlockHitResult bh = level.clip(new ClipContext(start, end,
                ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, viewer));
        double maxDist = bh.getType() == HitResult.Type.MISS ? range : bh.getLocation().distanceTo(start);

        AABB search = viewer.getBoundingBox().expandTowards(look.scale(range)).inflate(1.0);
        PhysicsProp best = null;
        double bestDist = maxDist + 0.05;
        for (PhysicsProp p : level.getEntitiesOfClass(PhysicsProp.class, search, e -> e != ignore && !e.isHeld())) {
            AABB box = p.getBoundingBox().inflate(0.05);
            double d;
            if (box.contains(start)) {
                d = 0;
            } else {
                Optional<Vec3> hit = box.clip(start, end);
                if (hit.isEmpty()) continue;
                d = hit.get().distanceTo(start);
            }
            if (d < bestDist) {
                bestDist = d;
                best = p;
            }
        }
        return best;
    }

    // ------------------------------------------------------------ actions from client

    public static void handleAction(ServerPlayer p, ActionPayload pl) {
        if (!Float.isFinite(pl.a()) || !Float.isFinite(pl.b())) return;
        if (p.isSpectator()) return;
        switch (pl.action()) {
            case ActionPayload.TOGGLE -> toggle(p);
            case ActionPayload.SCROLL -> {
                Grab g = GRABS.get(p.getUUID());
                if (g != null) g.dist = Mth.clamp(g.dist + Mth.clamp(pl.a(), -3f, 3f) * 0.4, 1.2, Config.GRAB_RANGE.get());
            }
            case ActionPayload.ROTATE -> {
                PhysicsProp prop = heldProp(p);
                if (prop != null) prop.rotateHeld(Mth.clamp(pl.a(), -15f, 15f), Mth.clamp(pl.b(), -15f, 15f));
            }
            case ActionPayload.THROW -> throwHeld(p);
            case ActionPayload.PLACE -> placeHeld(p);
            default -> { }
        }
    }

    private static PhysicsProp heldProp(ServerPlayer p) {
        Grab g = GRABS.get(p.getUUID());
        if (g == null) return null;
        Entity e = p.serverLevel().getEntity(g.entityId);
        return e instanceof PhysicsProp prop && !prop.isRemoved() ? prop : null;
    }

    private static void toggle(ServerPlayer p) {
        Grab existing = GRABS.get(p.getUUID());
        if (existing != null) {
            PhysicsProp prop = heldProp(p);
            if (prop != null) prop.release(Vec3.ZERO, false);
            endGrab(p);
            return;
        }
        double range = Config.GRAB_RANGE.get();
        PhysicsProp target = rayTrace(p, range, null);
        if (target == null) return;
        if (p.isShiftKeyDown() && target.getContentCount() > 0) {
            PhysicsProp out = target.popOne();
            if (out == null) return;
            target = out;
        }
        if (target.getHolder() != null) return;
        double dist = Mth.clamp(p.getEyePosition().distanceTo(target.getBoundingBox().getCenter()), 1.2, range);
        GRABS.put(p.getUUID(), new Grab(target.getId(), dist));
        target.hold(p, target.getBoundingBox().getCenter());
        GRABS.get(p.getUUID()).started = true;
        PacketDistributor.sendToPlayer(p, new HoldStatePayload(true));
        p.displayClientMessage(Component.translatable("message.lostphysics.holding"), true);
        p.level().playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.ITEM_PICKUP, SoundSource.PLAYERS, 0.3f, 1.2f);
    }

    private static void throwHeld(ServerPlayer p) {
        PhysicsProp prop = heldProp(p);
        if (prop == null) return;
        double speed = Config.THROW_SPEED.get() / (1.0 + prop.getPropType().mass * 0.12);
        Vec3 v = p.getLookAngle().scale(speed);
        prop.release(v, true);
        p.level().playSound(null, p.getX(), p.getY(), p.getZ(), SoundEvents.PLAYER_ATTACK_SWEEP, SoundSource.PLAYERS, 0.4f, 1.0f);
        endGrab(p);
    }

    private static void placeHeld(ServerPlayer p) {
        PhysicsProp prop = heldProp(p);
        if (prop == null) return;
        PhysicsProp container = rayTrace(p, Config.GRAB_RANGE.get(), prop);
        if (container != null && container.getPropType().canHold(prop.getPropType()) && container.tryStore(prop)) {
            endGrab(p);
            return;
        }
        prop.placeDown();
        endGrab(p);
    }

    private static void endGrab(ServerPlayer p) {
        if (GRABS.remove(p.getUUID()) != null) {
            PacketDistributor.sendToPlayer(p, new HoldStatePayload(false));
        }
    }

    // ------------------------------------------------------------ per-tick

    @SubscribeEvent
    public static void onPlayerTick(PlayerTickEvent.Post event) {
        if (!(event.getEntity() instanceof ServerPlayer p)) return;
        Grab g = GRABS.get(p.getUUID());
        if (g != null) {
            tickHold(p, g);
        } else {
            tickPush(p);
        }
    }

    private static void tickHold(ServerPlayer p, Grab g) {
        Entity e = p.serverLevel().getEntity(g.entityId);
        if (!(e instanceof PhysicsProp prop) || prop.isRemoved()
                || (prop.getHolder() != null && !prop.getHolder().equals(p.getUUID()))
                || (prop.getHolder() == null && g.started)) {
            endGrab(p);
            return;
        }
        Vec3 eye = p.getEyePosition();
        Vec3 look = p.getLookAngle();
        Vec3 target = eye.add(look.scale(g.dist));
        BlockHitResult hit = p.level().clip(new ClipContext(eye, target,
                ClipContext.Block.COLLIDER, ClipContext.Fluid.NONE, p));
        if (hit.getType() != HitResult.Type.MISS) {
            double d = Math.max(0.6, hit.getLocation().distanceTo(eye) - 0.35);
            target = eye.add(look.scale(d));
        }
        Vec3 center = prop.getBoundingBox().getCenter();
        if (center.distanceTo(eye) > Config.GRAB_RANGE.get() + 3.0) {
            prop.release(Vec3.ZERO, false);
            endGrab(p);
            return;
        }
        prop.hold(p, target);
    }

    /** Walking into a prop pushes it, scaled by the prop's mass. */
    private static void tickPush(ServerPlayer p) {
        float fwd = p.zza;
        float side = p.xxa;
        if (Math.abs(fwd) < 0.01f && Math.abs(side) < 0.01f) return;
        double yaw = Math.toRadians(p.getYRot());
        double sin = Math.sin(yaw);
        double cos = Math.cos(yaw);
        double dx = side * cos - fwd * sin;
        double dz = fwd * cos + side * sin;
        double len = Math.sqrt(dx * dx + dz * dz);
        if (len < 1.0e-4) return;
        dx /= len;
        dz /= len;
        double walk = (p.isSprinting() ? 0.26 : 0.2) * Config.PUSH_STRENGTH.get();

        AABB zone = p.getBoundingBox().inflate(0.15, -0.1, 0.15);
        for (PhysicsProp prop : p.level().getEntitiesOfClass(PhysicsProp.class, zone, e -> !e.isHeld())) {
            Vec3 c = prop.getBoundingBox().getCenter();
            double tx = c.x - p.getX();
            double tz = c.z - p.getZ();
            if (tx * dx + tz * dz <= 0.0) continue;
            double k = Math.min(1.0, 2.5 / prop.getPropType().mass);
            double want = walk * k;
            Vec3 cur = prop.getDeltaMovement();
            double along = cur.x * dx + cur.z * dz;
            if (along < want) {
                double add = (want - along) * 0.6;
                prop.impulse(new Vec3(dx * add, 0, dz * add));
            }
        }
    }

    @SubscribeEvent
    public static void onLogout(PlayerEvent.PlayerLoggedOutEvent event) {
        if (event.getEntity() instanceof ServerPlayer p) {
            PhysicsProp prop = heldProp(p);
            if (prop != null) prop.release(Vec3.ZERO, false);
            GRABS.remove(p.getUUID());
        }
    }

    @SubscribeEvent
    public static void onServerStopped(ServerStoppedEvent event) {
        GRABS.clear();
        ACTIVE.clear();
    }
}
