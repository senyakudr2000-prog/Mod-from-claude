# Lost Physics (NeoForge 1.21.1, Java 21)

Physical props you can grab, push, throw, stack and store in containers.

Controls (Options > Controls > Lost Physics, all rebindable):
G grab/release (Shift+G on a crate/barrel takes out a stored item) | Wheel distance | R rotate (Shift+R pitch) |
LMB throw | RMB place gently (or put a small prop into the crate/barrel you look at) | Shift+RMB on a prop packs it back into an item.
Walking into props pushes them; punching them knocks them away.

Get props: creative tab "Lost Physics" or crafting recipes.

Config (lostphysics-common.toml): maxActiveProps, grabRange, throwSpeed, pushStrength.

Build: ./gradlew build  ->  build/libs/lostphysics-1.0.0.jar
